```python
import numpy as np
import matplotlib.pyplot as plt
```

# Question 1

## A


```python
# a)
fraction_list = []
for D in range(1,16):
    D_dimensional_points = np.random.uniform(low=-1, high=1, size=(1000,D))
    distance_to_the_origin = np.sqrt(np.sum(D_dimensional_points**2,axis=1))
    fraction = sum(distance_to_the_origin<1)/len(distance_to_the_origin)
    fraction_list.append(fraction)
```


```python
plt.bar(np.arange(1,16,1),fraction_list)
```




    <BarContainer object of 15 artists>




    
![png](output_4_1.png)
    


## B 


```python

fraction_D_2 = fraction_list[1]
# For D = 2
# Area of square at first quadrant is 1, area of the circle is pi/4
# Then, fraction of area of the circle to the cube on the first quadrant is pi/4, which is fraction_D_2
print("pi is", 4*fraction_D_2)

```

    pi is 3.188
    


```python
fraction_D_3 = fraction_list[2]
# For D = 3
# Volume of cube at first quadrant is 1, Volume of the circle is pi/8
# Then, fraction of area of the sphere to the cube on the first quadrant is pi/6, which is fraction_D_2
print("pi is", 6*fraction_D_3)

```

    pi is 3.204
    

## C


```python
fraction_list = []
for D in range(2,4):
    for s in [5000,10000,25000, 50000, 100000]:
        D_dimensional_points = np.random.uniform(low=-1, high=1, size=(s,D))
        distance_to_the_origin = np.sqrt(np.sum(D_dimensional_points**2,axis=1))
        fraction = sum(distance_to_the_origin<1)/len(distance_to_the_origin)
        fraction_list.append(fraction)
```


```python
fraction_D_2 = fraction_list[:int(len(fraction_list)/2)] #first half is for 2D
fraction_D_3 = fraction_list[int(len(fraction_list)/2):] #second half is for 3D
fraction_D_3
```




    [0.5212, 0.5327, 0.52648, 0.52262, 0.52303]




```python
rang = np.array(['5000','10000','25000', '50000','100000'])
fraction_D_2 = np.array(fraction_D_2)
plt.bar(rang,fraction_D_2*4,alpha = 0.4)
plt.ylim(3, 3.2)
plt.axhline(np.pi,color = 'r', label = 'Pi=3.1415..')
plt.title('Two Dimension')
plt.xlabel('Number of Points')
plt.ylabel('fraction/all')
plt.legend()
```




    <matplotlib.legend.Legend at 0x115f3e34100>




    
![png](output_11_1.png)
    



```python
rang = np.array(['5000','10000','25000', '50000','100000'])
fraction_D_3 = np.array(fraction_D_3)
plt.bar(rang,fraction_D_3*6,alpha = 0.4)
plt.ylim(3, 3.2)
plt.axhline(np.pi,color = 'r', label = 'Pi=3.1415..')
plt.title('Three Dimension')
plt.xlabel('Number of Points')
plt.ylabel('fraction/all')
plt.legend()
```




    <matplotlib.legend.Legend at 0x115f752fac0>




    
![png](output_12_1.png)
    


The bigger the number of points, the better the ratio approximates the pi value, which is 3.1415... As it can be seen from the plots, for two dimension 25000 points are enough to get a good estimation for the pi; however, as the number of dimension increases, more trials require to get acceptable approximation.

## D


```python
"""This algorithm creates 100 points then gets the nearest neighbors for each point then takes the average for each dimension."""

D_list = []
dist_min = 999999
dist_min_D = 9999999
count = 0
for D in range(1,16):
    D_dimensional_points = np.random.uniform(low=-1, high=1, size=(1000,D)) #Creates D-dimensional uniformly distrubited array
    for i in range(100):
        point = np.random.uniform(low=-1, high=1, size=(1,D)) #Creates a single point
        for j in range(1000):
            dist = np.linalg.norm(D_dimensional_points[j]-point) #finds the distance for each 1000 point
            if dist < dist_min: #Finds the minimum distance
                dist_min = dist
        count += dist_min # adds all the minimum distances for 100 points
    D_list.append(count/100)    #divides count by 100 and appends it to a list                   
```


```python
plt.bar(np.arange(1,16,1),D_list)
```




    <BarContainer object of 15 artists>




    
![png](output_16_1.png)
    





```python

```




    1.4324787404720871




```python

```




    1.4324787404720871



# Question 2

## A


```python
# Python program to read image using OpenCV
!pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\users\t460s\anaconda3\lib\site-packages (4.5.4.58)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\t460s\anaconda3\lib\site-packages (from opencv-python) (1.20.1)
    


```python
# Python program to read 
# image using matplotlib
  
# importing matplotlib modules
import matplotlib.image as mpimg
import matplotlib.pyplot as plt
  
# Read Images
img = mpimg.imread('foto.jpg')
  
# Output Images
plt.imshow(img)
```




    <matplotlib.image.AxesImage at 0x25e1ad7b970>




    
![png](output_23_1.png)
    


## B


```python
fig, axs = plt.subplots(1,3,figsize= (10,16))
first = img[:, :, 0]
second = img[:, :, 1]
third = img[:, :, 2]

cax_00 = axs[0].imshow(first)
axs[0].xaxis.set_major_formatter(plt.NullFormatter())  # kill xlabels
axs[0].yaxis.set_major_formatter(plt.NullFormatter())  # kill ylabels

cax_01 = axs[1].imshow(second)
axs[1].xaxis.set_major_formatter(plt.NullFormatter())
axs[1].yaxis.set_major_formatter(plt.NullFormatter())

cax_10 = axs[2].imshow(third)
axs[2].xaxis.set_major_formatter(plt.NullFormatter())
axs[2].yaxis.set_major_formatter(plt.NullFormatter())

```


    
![png](output_25_0.png)
    



```python
"""Above three different channels are displayed but the images are yellowish.
If one wonders about the real RGB looking, cmap plotting should be used.
Detailed information and the source of this code can be seen by the link:
https://stackoverflow.com/questions/39885178/how-can-i-see-the-rgb-channels-of-a-given-image-with-python
"""
import skimage.io as io
import matplotlib.pyplot as plt

# Read
img = io.imread('foto.jpg')

# Split
red = img[:, :, 0]
green = img[:, :, 1]
blue = img[:, :, 2]

# Plot
fig, axs = plt.subplots(2,2,figsize = (12,12))

cax_00 = axs[0,0].imshow(img)
axs[0,0].xaxis.set_major_formatter(plt.NullFormatter())  # kill xlabels
axs[0,0].yaxis.set_major_formatter(plt.NullFormatter())  # kill ylabels

cax_01 = axs[0,1].imshow(red, cmap='Reds')
fig.colorbar(cax_01, ax=axs[0,1])
axs[0,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[0,1].yaxis.set_major_formatter(plt.NullFormatter())

cax_10 = axs[1,0].imshow(green, cmap='Greens')
fig.colorbar(cax_10, ax=axs[1,0])
axs[1,0].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,0].yaxis.set_major_formatter(plt.NullFormatter())

cax_11 = axs[1,1].imshow(blue, cmap='Blues')
fig.colorbar(cax_11, ax=axs[1,1])
axs[1,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,1].yaxis.set_major_formatter(plt.NullFormatter())
plt.show()

```


    
![png](output_26_0.png)
    


## C


```python
mean_first = np.array(first.mean(axis = 1))
mean_second = np.array(second.mean(axis = 1))
mean_third = np.array(third.mean(axis = 1))
plt.plot(mean_first, label = 'First')
plt.plot(mean_second,label = 'Second')
plt.plot(mean_third,label = 'Third')
plt.legend()
```




    <matplotlib.legend.Legend at 0x25e1a4dabe0>




    
![png](output_28_1.png)
    


## D (solved two different ways)


```python
f = first.copy()
s = second.copy()
t = third.copy()
```


```python
for i in [f,s,t]:
    sag = i[:,i.shape[0]//2:] - i[:,:i.shape[0]//2]
    i[:,i.shape[0]//2:] = sag
    i[i<0] = 0
plt.imshow(t)
```




    <matplotlib.image.AxesImage at 0x25e193de490>




    
![png](output_31_1.png)
    



```python
# Plot
fig, axs = plt.subplots(2,2,figsize = (12,12))

cax_00 = axs[0,0].imshow(img)
axs[0,0].xaxis.set_major_formatter(plt.NullFormatter())  # kill xlabels
axs[0,0].yaxis.set_major_formatter(plt.NullFormatter())  # kill ylabels

cax_01 = axs[0,1].imshow(f, cmap='Reds')
fig.colorbar(cax_01, ax=axs[0,1])
axs[0,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[0,1].yaxis.set_major_formatter(plt.NullFormatter())

cax_10 = axs[1,0].imshow(s, cmap='Greens')
fig.colorbar(cax_10, ax=axs[1,0])
axs[1,0].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,0].yaxis.set_major_formatter(plt.NullFormatter())

cax_11 = axs[1,1].imshow(t, cmap='Blues')
fig.colorbar(cax_11, ax=axs[1,1])
axs[1,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,1].yaxis.set_major_formatter(plt.NullFormatter())
plt.show()

```


    
![png](output_32_0.png)
    



```python
ff = first.copy()
ss = second.copy()
tt = third.copy()
for img in [ff,ss,tt]:
    for i in range(512):
        for j in range(256):
            img[i][-1-j] = img[i][-1-j] - img[i][j]
    img[img<0] = 0
```

    <ipython-input-51-35607c70d814>:7: RuntimeWarning: overflow encountered in ubyte_scalars
      img[i][-1-j] = img[i][-1-j] - img[i][j]
    


```python
# Plot
fig, axs = plt.subplots(2,2,figsize = (12,12))

cax_00 = axs[0,0].imshow(img)
axs[0,0].xaxis.set_major_formatter(plt.NullFormatter())  # kill xlabels
axs[0,0].yaxis.set_major_formatter(plt.NullFormatter())  # kill ylabels

cax_01 = axs[0,1].imshow(ff, cmap='Reds')
fig.colorbar(cax_01, ax=axs[0,1])
axs[0,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[0,1].yaxis.set_major_formatter(plt.NullFormatter())

cax_10 = axs[1,0].imshow(ss, cmap='Greens')
fig.colorbar(cax_10, ax=axs[1,0])
axs[1,0].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,0].yaxis.set_major_formatter(plt.NullFormatter())

cax_11 = axs[1,1].imshow(tt, cmap='Blues')
fig.colorbar(cax_11, ax=axs[1,1])
axs[1,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,1].yaxis.set_major_formatter(plt.NullFormatter())
plt.show()

```


    
![png](output_34_0.png)
    


## E


```python
noised = img.copy()
noised
```




    array([[[241, 241, 241],
            [241, 241, 241],
            [241, 241, 241],
            ...,
            [240, 240, 240],
            [240, 240, 240],
            [240, 240, 240]],
    
           [[241, 241, 241],
            [241, 241, 241],
            [241, 241, 241],
            ...,
            [240, 240, 240],
            [240, 240, 240],
            [240, 240, 240]],
    
           [[241, 241, 241],
            [241, 241, 241],
            [241, 241, 241],
            ...,
            [240, 240, 240],
            [239, 239, 239],
            [239, 239, 239]],
    
           ...,
    
           [[ 36,  37,  42],
            [ 35,  36,  41],
            [ 32,  33,  38],
            ...,
            [ 31,  32,  36],
            [ 31,  32,  36],
            [ 30,  31,  35]],
    
           [[ 36,  37,  42],
            [ 34,  35,  40],
            [ 32,  33,  38],
            ...,
            [ 31,  32,  36],
            [ 30,  31,  35],
            [ 30,  31,  35]],
    
           [[ 35,  36,  41],
            [ 34,  35,  40],
            [ 31,  32,  37],
            ...,
            [ 31,  32,  36],
            [ 30,  31,  35],
            [ 30,  31,  35]]], dtype=uint8)




```python
noised = noised + np.rint(np.random.uniform(low=0, high=img.max()*0.1,size = (512,512,3)))
noised[noised > 255] = 255
noised =  noised.astype(np.int)
noised
```

    <ipython-input-92-b8982524a4b9>:3: DeprecationWarning: `np.int` is a deprecated alias for the builtin `int`. To silence this warning, use `int` by itself. Doing this will not modify any behavior and is safe. When replacing `np.int`, you may wish to use e.g. `np.int64` or `np.int32` to specify the precision. If you wish to review your current use, check the release note link for additional information.
    Deprecated in NumPy 1.20; for more details and guidance: https://numpy.org/devdocs/release/1.20.0-notes.html#deprecations
      noised =  noised.astype(np.int)
    




    array([[[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [255, 255, 255]],
    
           [[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [255, 255, 255]],
    
           [[255, 255, 255],
            [255, 255, 255],
            [255, 255, 255],
            ...,
            [255, 255, 255],
            [255, 255, 255],
            [255, 255, 255]],
    
           ...,
    
           [[172, 138, 124],
            [172, 170, 176],
            [166, 166, 164],
            ...,
            [166, 152, 144],
            [138, 167, 144],
            [133, 156, 160]],
    
           [[170, 119, 200],
            [157, 110, 167],
            [145, 137, 175],
            ...,
            [118, 148, 174],
            [175, 123, 163],
            [135, 121,  93]],
    
           [[132, 140, 166],
            [162, 134, 140],
            [119, 158, 120],
            ...,
            [133, 151, 154],
            [146, 140, 137],
            [145, 171,  96]]])




```python
# Plot
fig, axs = plt.subplots(2,2,figsize = (12,12))

cax_00 = axs[0,0].imshow(noised)
axs[0,0].xaxis.set_major_formatter(plt.NullFormatter())  # kill xlabels
axs[0,0].yaxis.set_major_formatter(plt.NullFormatter())  # kill ylabels

cax_01 = axs[0,1].imshow(ff, cmap='Reds')
fig.colorbar(cax_01, ax=axs[0,1])
axs[0,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[0,1].yaxis.set_major_formatter(plt.NullFormatter())

cax_10 = axs[1,0].imshow(ss, cmap='Greens')
fig.colorbar(cax_10, ax=axs[1,0])
axs[1,0].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,0].yaxis.set_major_formatter(plt.NullFormatter())

cax_11 = axs[1,1].imshow(tt, cmap='Blues')
fig.colorbar(cax_11, ax=axs[1,1])
axs[1,1].xaxis.set_major_formatter(plt.NullFormatter())
axs[1,1].yaxis.set_major_formatter(plt.NullFormatter())
plt.show()

```


    
![png](output_38_0.png)
    



```python

```
